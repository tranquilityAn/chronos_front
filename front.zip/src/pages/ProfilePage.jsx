import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { getCurrentUser, updateUser, updateUserAvatar } from '../features/user/userApi';
import { logout, updateUser as updateUserAction } from '../features/auth/authSlice';
import HeaderBar from '../components/calendar/HeaderBar';
import Sidebar from '../components/calendar/Sidebar';
import Toast, { useToast } from '../components/ui/Toast';
import '../styles/calendar.css';
import './ProfilePage.css';

export default function ProfilePage() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { toast, showToast, hideToast } = useToast();
    
    const token = useSelector((state) => state.auth.token);
    const userFromStore = useSelector((state) => state.auth.user);

    const [user, setUser] = useState(userFromStore);
    const [isLoading, setIsLoading] = useState(true);
    const [isEditing, setIsEditing] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
    const [avatarError, setAvatarError] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        country: '',
    });

    // Проверка авторизации
    useEffect(() => {
        if (!token) {
            navigate('/login', { replace: true });
        }
    }, [token, navigate]);

    // Загрузка данных пользователя
    useEffect(() => {
        const loadUser = async () => {
            if (!token) return;
            
            try {
                setIsLoading(true);
                const userData = await getCurrentUser();
                console.log('Loaded user data:', userData);
                console.log('Avatar URL:', userData?.avatar);
                setUser(userData);
                dispatch(updateUserAction(userData));
                setAvatarError(false); // Сбрасываем ошибку при загрузке
                setFormData({
                    name: userData.name || '',
                    country: userData.country || '',
                });
            } catch (error) {
                console.error('Error loading user:', error);
                showToast('Ошибка загрузки данных пользователя', 'error');
            } finally {
                setIsLoading(false);
            }
        };

        loadUser();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [token, dispatch]);

    // Сбрасываем ошибку при изменении аватара
    useEffect(() => {
        setAvatarError(false);
    }, [user?.avatar]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    const handleSave = async () => {
        try {
            setIsSaving(true);
            const updatedUser = await updateUser({
                name: formData.name || '',
                country: formData.country || '',
            });
            setUser(updatedUser);
            dispatch(updateUserAction(updatedUser));
            setIsEditing(false);
            showToast('Профиль успешно обновлен', 'success');
        } catch (error) {
            console.error('Error updating user:', error);
            showToast(error?.response?.data?.error || 'Ошибка обновления профиля', 'error');
        } finally {
            setIsSaving(false);
        }
    };

    const handleCancel = () => {
        setFormData({
            name: user?.name || '',
            country: user?.country || '',
        });
        setIsEditing(false);
    };

    const handleAvatarChange = async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;

        // Проверка типа файла
        if (!file.type.startsWith('image/')) {
            showToast('Пожалуйста, выберите изображение', 'error');
            return;
        }

        // Проверка размера (максимум 5MB)
        if (file.size > 5 * 1024 * 1024) {
            showToast('Размер файла не должен превышать 5MB', 'error');
            return;
        }

        try {
            setIsUploadingAvatar(true);
            const updatedUser = await updateUserAvatar(file);
            setUser(updatedUser);
            dispatch(updateUserAction(updatedUser));
            setAvatarError(false); // Сбрасываем ошибку после успешного обновления
            showToast('Аватар успешно обновлен', 'success');
        } catch (error) {
            console.error('Error updating avatar:', error);
            showToast(error?.response?.data?.error || 'Ошибка обновления аватара', 'error');
        } finally {
            setIsUploadingAvatar(false);
            e.target.value = ''; // Сброс input
        }
    };

    const handleLogout = () => {
        dispatch(logout());
        navigate('/login');
    };

    const getInitials = (name, email) => {
        // Если есть имя, формируем инициалы из имени
        if (name && typeof name === 'string' && name.trim()) {
            const parts = name.trim().split(/\s+/).filter(part => part.length > 0);
            if (parts.length >= 2) {
                // Если несколько слов, берем первую букву первого и последнего слова
                const first = parts[0][0] || '';
                const last = parts[parts.length - 1][0] || '';
                return (first + last).toUpperCase();
            }
            if (parts.length === 1 && parts[0].length >= 2) {
                // Если одно слово, берем первые две буквы
                return parts[0].substring(0, 2).toUpperCase();
            }
            if (parts.length === 1) {
                // Если одно слово из одной буквы
                return parts[0][0].toUpperCase();
            }
        }
        
        // Если имени нет, формируем из email
        if (email && typeof email === 'string' && email.trim()) {
            const emailClean = email.trim();
            const atIndex = emailClean.indexOf('@');
            if (atIndex > 0) {
                // Берем первые две буквы до символа @
                const beforeAt = emailClean.substring(0, atIndex);
                if (beforeAt.length >= 2) {
                    return beforeAt.substring(0, 2).toUpperCase();
                }
                return beforeAt[0].toUpperCase();
            }
            if (emailClean.length >= 2) {
                return emailClean.substring(0, 2).toUpperCase();
            }
            return emailClean[0].toUpperCase();
        }
        
        // Если ничего нет, возвращаем дефолтный символ
        return 'U';
    };

    if (isLoading) {
        return (
            <div className="calendar-page">
                <Sidebar
                    serviceName="Houdini"
                    myCalendars={[]}
                    sharedCalendars={[]}
                    onToggleCalendar={() => {}}
                    onAddEvent={() => {}}
                    onAddCalendar={() => {}}
                    onEditCalendar={() => {}}
                />
                <div className="calendar-main">
                    <HeaderBar 
                        activeDate={new Date()}
                        onPrevMonth={() => {}}
                        onNextMonth={() => {}}
                        onToday={() => {}}
                        onLogout={handleLogout}
                        isLoading={false}
                    />
                    <div className="profile-page">
                        <div className="profile-page__loading">Загрузка...</div>
                    </div>
                </div>
            </div>
        );
    }

    if (!user) {
        return (
            <div className="calendar-page">
                <div className="profile-page">
                    <div className="profile-page__error">Пользователь не найден</div>
                </div>
            </div>
        );
    }

    const isLoadingForHeader = false; // Для HeaderBar

    return (
        <div className="calendar-page">
            <Sidebar
                serviceName="Houdini"
                myCalendars={[]}
                sharedCalendars={[]}
                onToggleCalendar={() => {}}
                onAddEvent={() => {}}
                onAddCalendar={() => {}}
                onEditCalendar={() => {}}
            />

            <div className="calendar-main">
                <HeaderBar 
                    activeDate={new Date()}
                    onPrevMonth={() => {}}
                    onNextMonth={() => {}}
                    onToday={() => {}}
                    onLogout={handleLogout}
                    isLoading={isLoadingForHeader}
                />
                
                <div className="profile-page">
                    <div className="profile-page__container">
                        <div className="profile-page__header">
                            <h1 className="profile-page__title">Профиль пользователя</h1>
                        </div>

                        <div className="profile-page__content">
                    {/* Аватар */}
                        <div className="profile-page__avatar-section">
                        <div className="profile-page__avatar-wrapper">
                            {(() => {
                                const hasAvatar = !avatarError &&
                                                  user.avatar && 
                                                  typeof user.avatar === 'string' && 
                                                  user.avatar.trim() !== '' && 
                                                  user.avatar !== 'null' && 
                                                  user.avatar !== 'undefined' &&
                                                  !user.avatar.toLowerCase().includes('null');
                                
                                if (hasAvatar) {
                                    return (
                                        <>
                                            <img 
                                                key={user.avatar} // Добавляем key для перезагрузки при изменении
                                                src={user.avatar} 
                                                alt={user.name || user.email}
                                                className="profile-page__avatar"
                                                onError={(e) => {
                                                    // Если изображение не загрузилось, показываем инициалы
                                                    console.error('Failed to load avatar image:', user.avatar);
                                                    setAvatarError(true);
                                                    e.target.style.display = 'none';
                                                }}
                                                onLoad={() => {
                                                    // Успешно загружено, сбрасываем ошибку
                                                    setAvatarError(false);
                                                }}
                                            />
                                            {avatarError && (
                                                <div className="profile-page__avatar-placeholder">
                                                    {getInitials(user.name, user.email)}
                                                </div>
                                            )}
                                        </>
                                    );
                                }
                                return (
                                    <div className="profile-page__avatar-placeholder">
                                        {getInitials(user.name, user.email)}
                                    </div>
                                );
                            })()}
                            <div className="profile-page__avatar-overlay">
                                <label className="profile-page__avatar-upload-btn">
                                    {isUploadingAvatar ? 'Загрузка...' : 'Изменить'}
                                    <input
                                        type="file"
                                        accept="image/*"
                                        onChange={handleAvatarChange}
                                        disabled={isUploadingAvatar}
                                        style={{ display: 'none' }}
                                    />
                                </label>
                            </div>
                        </div>
                    </div>

                    {/* Информация о пользователе */}
                    <div className="profile-page__info">
                        <div className="profile-page__info-row">
                            <label className="profile-page__label">Email</label>
                            <div className="profile-page__value profile-page__value--readonly">
                                {user.email}
                            </div>
                        </div>

                        <div className="profile-page__info-row">
                            <label className="profile-page__label">Имя</label>
                            {isEditing ? (
                                <input
                                    type="text"
                                    name="name"
                                    className="profile-page__input"
                                    value={formData.name}
                                    onChange={handleChange}
                                    placeholder="Введите имя"
                                />
                            ) : (
                                <div className="profile-page__value">
                                    {user.name || 'Не указано'}
                                </div>
                            )}
                        </div>

                        <div className="profile-page__info-row">
                            <label className="profile-page__label">Страна</label>
                            {isEditing ? (
                                <input
                                    type="text"
                                    name="country"
                                    className="profile-page__input"
                                    value={formData.country}
                                    onChange={handleChange}
                                    placeholder="Код страны (например, US, UA)"
                                    maxLength={2}
                                    style={{ textTransform: 'uppercase' }}
                                />
                            ) : (
                                <div className="profile-page__value">
                                    {user.country || 'Не указано'}
                                </div>
                            )}
                        </div>

                        {/* Кнопки действий */}
                        <div className="profile-page__actions">
                            {isEditing ? (
                                <>
                                    <button
                                        className="profile-page__btn profile-page__btn--save"
                                        onClick={handleSave}
                                        disabled={isSaving}
                                    >
                                        {isSaving ? 'Сохранение...' : 'Сохранить'}
                                    </button>
                                    <button
                                        className="profile-page__btn profile-page__btn--cancel"
                                        onClick={handleCancel}
                                        disabled={isSaving}
                                    >
                                        Отмена
                                    </button>
                                </>
                            ) : (
                                <button
                                    className="profile-page__btn profile-page__btn--edit"
                                    onClick={() => setIsEditing(true)}
                                >
                                    Редактировать
                                </button>
                            )}
                        </div>
                    </div>
                </div>
                
                {/* Toast уведомления */}
                <Toast
                    message={toast.message}
                    type={toast.type}
                    isVisible={toast.isVisible}
                    onClose={hideToast}
                />
            </div>
        </div>
    );
}

